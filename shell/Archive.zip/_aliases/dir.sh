alias i.="idea ."
alias o.="open ."
alias c.="code ."
